
#pragma once

#include "cpuinfo_impl.h"

namespace cpuid {

void init_cpuinfo(cpuinfo::impl& info) { (void)info; }
}  // namespace cpuid
